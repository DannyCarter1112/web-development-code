console.log("This is my first programe")// displays text in the speach marks when activated
console.log("Well come John your month salary is 500000") // displays text in the speach marks when activated

console.log("") // spaces
console.log("")// spaces
console.log("")// spaces


const ps = require("prompt-sync");
const prompt = ps();
const number = parseInt(prompt("Enter a number"));// this puts a prompt for a user to enter on

// this code below checks if the number is more than 0
if (number > 0 ) {
    console.log(" The number is positive");

}

// this code below check to see if the number is zero itself
else if (number == 0){
    console.log("The number is 0");
}

// this code below checks to see if the number is less than zero
else {
    console.log("The number is negative");
}















let num1 = 72; // this esablishes what variable num1 is 
let num2 = 6; // this establishes what variable num2 is // replace with line 11 f code ????????????????????/
let Addition = num1 + num2; // this means when when addition is entered into the code num1 and num2 are added together
let Subtraction = num1 - num2; //this means when subraction is entered into the code num1 and num2 are subrtaced from eachother
let Multiply = num1 * num2; // this means when multiply is entered into the code num1 and num2 are miltiplied from eachother
let Divide = num1 / num2; // this means when divide is entered into the code num1 and num2 are divided from eachother

//the following code adds two variables and displays what is in the "" as well as the result
console.log("72 + 6 =");
 console.log(Addition) 

console.log("") // spaces

//the following code subtracts two variables and displays what is in the "" as well as the result
console.log("72 - 6 =");
 console.log(Subtraction) 


 console.log("") // spaces

//the following code multiplys two variables and displays is in the "" as well as the result
 console.log("72 X 6 =");
 console.log(Multiply) 

 console.log("") // spaces 

 //the following code divides two variables and displays is in the "" as well as the result
 console.log("72 / 6 ="); 
 console.log(Divide) 

 console.log("") // spaces 

 